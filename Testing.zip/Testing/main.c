#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdbool.h>

// Define a Sprite structure
typedef struct Sprite {
    SDL_Texture* texture;  // The sprite's texture
    SDL_Rect rect;         // The sprite's position and size
} Sprite;

// Function to create a white texture if no image path is provided
SDL_Texture* createWhiteTexture(SDL_Renderer* renderer, int w, int h) {
    // Create a blank surface
    SDL_Surface* surface = SDL_CreateRGBSurface(0, w, h, 32, 0, 0, 0, 0);
    if (!surface) {
        printf("Failed to create surface! SDL_Error: %s\n", SDL_GetError());
        return NULL;
    }

    // Fill the surface with white
    SDL_FillRect(surface, NULL, SDL_MapRGB(surface->format, 255, 255, 255));

    // Create a texture from the surface
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);  // Free the surface after creating the texture

    if (!texture) {
        printf("Failed to create texture from surface! SDL_Error: %s\n", SDL_GetError());
    }

    return texture;
}

// Function to create a sprite
Sprite createSprite(SDL_Renderer* renderer, const char* imagePath, int x, int y, int w, int h) {
    SDL_Texture* texture = NULL;

    // Check if an image path is provided
    if (imagePath != NULL && imagePath[0] != '\0') {
        // Load image as a surface
        SDL_Surface* surface = SDL_LoadBMP(imagePath);
        if (!surface) {
            printf("Failed to load image %s! SDL_Error: %s\n", imagePath, SDL_GetError());
            exit(1);
        }
        
        // Create texture from the surface
        texture = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_FreeSurface(surface);  // Free the surface after creating the texture
        
        if (!texture) {
            printf("Failed to create texture! SDL_Error: %s\n", SDL_GetError());
            exit(1);
        }
    } else {
        // Create a white texture if no image is provided
        texture = createWhiteTexture(renderer, w, h);
    }

    // Initialize the sprite with the texture, position, and size
    Sprite sprite;
    sprite.texture = texture;
    sprite.rect.x = x;
    sprite.rect.y = y;
    sprite.rect.w = w;
    sprite.rect.h = h;

    return sprite;
}

// Function to render the sprite
void renderSprite(SDL_Renderer* renderer, Sprite* sprite) {
    SDL_RenderCopy(renderer, sprite->texture, NULL, &sprite->rect);
}

// Function to clean up a sprite
void destroySprite(Sprite* sprite) {
    SDL_DestroyTexture(sprite->texture);
}

// Main function demonstrating sprite rendering
int main(int argc, char* argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("SDL White Surface Demo",
                                          SDL_WINDOWPOS_UNDEFINED,
                                          SDL_WINDOWPOS_UNDEFINED,
                                          640, 480,
                                          SDL_WINDOW_SHOWN);
    if (!window) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Create a sprite with a white surface (without image)
    Sprite player = createSprite(renderer, "", 100, 100, 50, 50);  // Blank white square

    bool running = true;
    SDL_Event event;
    int speed = 5;

    // Game loop
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.sym) {
                    case SDLK_ESCAPE:
                        running = false;
                        break;
                    case SDLK_UP:
                        player.rect.y -= speed;
                        break;
                    case SDLK_DOWN:
                        player.rect.y += speed;
                        break;
                    case SDLK_LEFT:
                        player.rect.x -= speed;
                        break;
                    case SDLK_RIGHT:
                        player.rect.x += speed;
                        break;
                }
            }
        }

        // Clear the screen with a black color
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        // Render the sprite
        renderSprite(renderer, &player);

        // Present the rendered frame
        SDL_RenderPresent(renderer);

        SDL_Delay(16);  // Delay to control frame rate (~60 FPS)
    }

    // Clean up resources
    destroySprite(&player);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
